export interface DataInf{
    EmpId:number,
    EmpName:string,
    EmpDesig:string,
    EmpDept:string,
    EmpSal:number
}