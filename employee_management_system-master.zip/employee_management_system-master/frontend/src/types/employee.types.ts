export interface EmpObjectType{
    EmpId:number,
    EmpName:string,
    EmpDesig:string,
    EmpDept:string,
    EmpSal:number
}
export interface MsgType{
    [msg:string]:string
}